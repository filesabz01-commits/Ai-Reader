package app.aireader

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** kind: 0 = Gemini, 1 = OpenAI-compatible, 2 = Claude (Anthropic) */
data class ProviderInfo(val id: String, val label: String, val defModel: String, val defBase: String, val kind: Int)

object Providers {
    val all = listOf(
        ProviderInfo("gemini", "Gemini", "gemini-2.5-flash", "https://generativelanguage.googleapis.com/v1beta", 0),
        ProviderInfo("openai", "OpenAI", "gpt-4o-mini", "https://api.openai.com/v1", 1),
        ProviderInfo("claude", "Claude", "claude-sonnet-5-5", "https://api.anthropic.com/v1", 2),
        ProviderInfo("openrouter", "OpenRouter", "openai/gpt-4o-mini", "https://openrouter.ai/api/v1", 1),
        ProviderInfo("custom", "Custom (OpenAI-compatible API)", "", "", 1)
    )
    fun byId(id: String): ProviderInfo = all.firstOrNull { it.id == id } ?: all[0]
}

object Langs {
    val all = listOf(
        "Persian" to "fa-IR", "English" to "en-US", "Arabic" to "ar", "Turkish" to "tr-TR",
        "French" to "fr-FR", "German" to "de-DE", "Spanish" to "es-ES", "Russian" to "ru-RU", "Chinese" to "zh-CN"
    )
    fun tag(name: String): String = all.firstOrNull { it.first == name }?.second ?: "en-US"
}

class AiException(msg: String) : Exception(msg)

object Ai {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json".toMediaType()

    suspend fun ask(p: Prefs, system: String, user: String): String = withContext(Dispatchers.IO) {
        val info = Providers.byId(p.provider.value)
        val key = p.key(info.id)
        val model = p.model(info.id)
        val base = p.base(info.id).trimEnd('/')
        if (key.isBlank()) throw AiException("No API key for ${info.label}. Open Settings → AI Providers and paste your key.")
        if (model.isBlank()) throw AiException("No model selected for ${info.label}. Open Settings → AI Providers.")
        if (base.isBlank()) throw AiException("No base URL set for ${info.label}.")

        val rb = Request.Builder()
        when (info.kind) {
            0 -> {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", user)))))
                rb.url("$base/models/$model:generateContent").header("x-goog-api-key", key)
                    .post(body.toString().toRequestBody(JSON))
            }
            2 -> {
                val body = JSONObject().put("model", model).put("max_tokens", 4096).put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
                rb.url("$base/messages").header("x-api-key", key).header("anthropic-version", "2023-06-01")
                    .post(body.toString().toRequestBody(JSON))
            }
            else -> {
                val body = JSONObject().put("model", model).put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user)))
                rb.url("$base/chat/completions").header("Authorization", "Bearer $key")
                    .post(body.toString().toRequestBody(JSON))
            }
        }
        client.newCall(rb.build()).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw AiException("${info.label} error ${r.code}: ${txt.take(300)}")
            try {
                val j = JSONObject(txt)
                when (info.kind) {
                    0 -> {
                        val parts = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                        buildString { for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text")) }
                    }
                    2 -> {
                        val c = j.getJSONArray("content")
                        buildString { for (i in 0 until c.length()) append(c.getJSONObject(i).optString("text")) }
                    }
                    else -> j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
                }.trim()
            } catch (e: Exception) {
                throw AiException("Unexpected response from ${info.label}: ${txt.take(200)}")
            }
        }
    }

    suspend fun models(p: Prefs, id: String): List<String> = withContext(Dispatchers.IO) {
        val info = Providers.byId(id)
        val key = p.key(id)
        val base = p.base(id).trimEnd('/')
        if (key.isBlank()) throw AiException("Enter the API key first.")
        val rb = Request.Builder()
        when (info.kind) {
            0 -> rb.url("$base/models?pageSize=200").header("x-goog-api-key", key)
            2 -> rb.url("$base/models?limit=100").header("x-api-key", key).header("anthropic-version", "2023-06-01")
            else -> rb.url("$base/models").header("Authorization", "Bearer $key")
        }
        client.newCall(rb.build()).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw AiException("Error ${r.code}: ${txt.take(200)}")
            val j = JSONObject(txt)
            val out = mutableListOf<String>()
            if (info.kind == 0) {
                val a = j.getJSONArray("models")
                for (i in 0 until a.length()) out.add(a.getJSONObject(i).optString("name").removePrefix("models/"))
            } else {
                val a = j.getJSONArray("data")
                for (i in 0 until a.length()) out.add(a.getJSONObject(i).optString("id"))
            }
            out.filter { it.isNotBlank() }.sorted()
        }
    }
}

object Prompts {
    const val base = "You are an expert assistant embedded in a PDF reader used to study technical and engineering books. " +
        "Be accurate, concise and never invent facts that are not supported by the given text."

    fun translate(lang: String) = "You are a precise technical translator. Translate the user's text into $lang. " +
        "Return ONLY a JSON array of objects {\"o\": original sentence or short paragraph, \"t\": its translation}. " +
        "Keep the original order and cover ALL of the text. Keep technical terms accurate. " +
        "Ignore page numbers and running headers/footers. No markdown, no commentary, no code fences."

    fun explain(lang: String, level: Int) = "$base Explain the given passage to the reader. Answer in $lang (keep key English technical terms in parentheses). " +
        when (level) {
            0 -> "Explain very simply, as to a smart beginner, with one everyday analogy."
            2 -> "Explain technically, as an engineer would: precise terminology, assumptions, typical values where relevant."
            else -> "Explain clearly and concisely."
        } + " Use short paragraphs or bullets. Only use **bold** for Markdown."

    fun summarize(lang: String) = "$base Summarize the given text in $lang in at most 6 short bullet points. Keep key English terms in parentheses."
    fun keyPoints(lang: String) = "$base List the key points of the given page in $lang as concise bullets. Put important terms in **bold** with the English term in parentheses."
    fun study(lang: String) = "$base Create study material from this page, written in $lang (keep English terms in parentheses). " +
        "Use these sections with bold titles: **Key points**, **Terms** (term — definition), **Quiz** (5 questions, each followed by its answer), **Flashcards** (6 lines in the form Q → A)."
    fun askCtx(lang: String) = "$base Answer the question using ONLY the given context. If the context does not contain the answer, say so. Answer in $lang unless the question is in another language; keep English technical terms in parentheses."
    fun askBook(lang: String) = "$base You are given excerpts from a book, each labelled with its page number. Answer the question using ONLY these excerpts and cite page numbers like (p. 24). " +
        "If the excerpts do not answer it, say so. Answer in $lang unless the question is in another language; keep English technical terms in parentheses."
    fun keywords(q: String) = "A reader asks a question about a technical book. Output 6-12 English keywords and synonyms likely to appear in the relevant pages, comma separated, nothing else.\nQuestion: $q"
    const val analyze = "$base Analyze this page and pick the important passages. Return ONLY a JSON array (no code fences). " +
        "Each element: {\"type\": one of definition|formula|important|warning|term|example, \"text\": an EXACT verbatim substring copied from the page, under 300 characters}. At most 15 elements."
    fun cleanForTts(tableMode: Int) = "Prepare this PDF page text for text-to-speech reading. Remove page numbers, running headers/footers, figure/table labels and reference clutter. " +
        "Fix broken line wraps and hyphenation. " + when (tableMode) {
            0 -> "Omit tables completely."
            1 -> "Replace each table with one short sentence saying what the table contains."
            else -> "Read tables out as natural sentences."
        } + " Do NOT summarize or change the wording of the body text. Output plain text only."
    const val tocBuilder = "$base Below are candidate headings extracted from a book, as lines 'page|text' (some may be false positives). " +
        "Build a clean hierarchical table of contents. Output ONLY lines in the form level|title|page where level is 0 for chapters, 1 for sections, 2 for subsections. Drop false positives."

    fun parsePairs(raw: String, fallbackOriginal: String): List<Pair<String, String>> {
        return try {
            var s = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val a = s.indexOf('['); val b = s.lastIndexOf(']')
            if (a >= 0 && b > a) s = s.substring(a, b + 1)
            val arr = JSONArray(s)
            val out = mutableListOf<Pair<String, String>>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(o.optString("o") to o.optString("t"))
            }
            if (out.isEmpty()) listOf(fallbackOriginal to raw) else out
        } catch (e: Exception) {
            listOf(fallbackOriginal to raw)
        }
    }

    fun parseFound(raw: String): List<Pair<String, String>> = try {
        var s = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = s.indexOf('['); val b = s.lastIndexOf(']')
        if (a >= 0 && b > a) s = s.substring(a, b + 1)
        val arr = JSONArray(s)
        (0 until arr.length()).map { arr.getJSONObject(it) }
            .map { it.optString("type", "important") to it.optString("text") }
            .filter { it.second.isNotBlank() }
    } catch (e: Exception) { emptyList() }
}
