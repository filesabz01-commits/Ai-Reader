package app.aireader

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class Sheet(
    val title: String,
    val busy: Boolean = true,
    val error: String? = null,
    val text: String = "",
    val pairs: List<Pair<String, String>>? = null,
    val found: List<Pair<String, String>>? = null,
    val hits: List<Pair<Int, String>>? = null,
    val page: Int = -1
)

class AppVm(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication()
    val prefs = Prefs(app)

    var screen by mutableIntStateOf(0)        // 0 home, 1 reader, 2 settings
    var backTo by mutableIntStateOf(0)
    var doc by mutableStateOf<PdfDoc?>(null)
    var ann by mutableStateOf<Annotations?>(null)
    var page by mutableIntStateOf(0)
    var opening by mutableStateOf(false)
    var openError by mutableStateOf<String?>(null)
    var indexDone by mutableStateOf(false)
    var indexProgress by mutableIntStateOf(0)
    var repeated by mutableStateOf<Set<String>>(emptySet())
    val toc = mutableStateListOf<TocItem>()
    val recents = mutableStateListOf<Recent>()

    var sheet by mutableStateOf<Sheet?>(null)
    var askKind by mutableIntStateOf(-1)      // -1 none, 0 page, 1 selection, 2 whole book
    private var askText = ""
    private var job: Job? = null

    var speaking by mutableStateOf(false)
    var nowSpeaking by mutableStateOf("")
    private var speaker: Speaker? = null
    private val main = Handler(Looper.getMainLooper())
    private val trCache = HashMap<String, List<Pair<String, String>>>()

    init { loadRecents() }

    // ---------------------------------------------------------------- documents
    private fun loadRecents() {
        try {
            val a = JSONArray(prefs.sp.getString("recent", "[]"))
            for (i in 0 until a.length()) a.getJSONObject(i).let { recents.add(Recent(it.getString("u"), it.getString("t"))) }
        } catch (_: Exception) {}
    }

    private fun addRecent(uri: Uri, title: String) {
        recents.removeAll { it.uri == uri.toString() }
        recents.add(0, Recent(uri.toString(), title))
        while (recents.size > 20) recents.removeAt(recents.size - 1)
        val a = JSONArray(); recents.forEach { a.put(JSONObject().put("u", it.uri).put("t", it.title)) }
        prefs.sp.edit().putString("recent", a.toString()).apply()
    }

    fun lastPageOf(uri: String): Int =
        ctx.getSharedPreferences("last", Context.MODE_PRIVATE).getInt(Integer.toHexString(uri.hashCode()), 0)

    fun open(uri: Uri) {
        viewModelScope.launch {
            opening = true; openError = null
            try {
                try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val d = PdfDoc(ctx, uri)
                d.open()
                stopSpeaking(); doc?.close()
                doc = d; ann = Annotations(ctx, d.id)
                page = ctx.getSharedPreferences("last", Context.MODE_PRIVATE).getInt(d.id, 0).coerceIn(0, d.pageCount - 1)
                toc.clear(); indexDone = false; indexProgress = 0; repeated = emptySet(); sheet = null; askKind = -1
                addRecent(uri, d.title)
                screen = 1
                startIndex(d)
            } catch (e: Exception) {
                openError = "Couldn't open this PDF: ${e.message}"
            } finally { opening = false }
        }
    }

    private fun startIndex(d: PdfDoc) {
        viewModelScope.launch {
            val n = d.pageCount
            val sample = (0 until 14).map { (it * (n - 1).coerceAtLeast(1)) / 13 }.distinct().map { d.pageText(it.coerceIn(0, n - 1)) }
            repeated = TextClean.repeated(sample)
            d.indexAll { indexProgress = it }
            indexDone = true
            val t = d.outline().ifEmpty { d.headings() }
            toc.clear(); toc.addAll(t)
        }
    }

    fun goto(p: Int) {
        val d = doc ?: return
        page = p.coerceIn(0, d.pageCount - 1)
        ctx.getSharedPreferences("last", Context.MODE_PRIVATE).edit().putInt(d.id, page).apply()
    }

    // ---------------------------------------------------------------- AI plumbing
    private fun run(title: String, block: suspend () -> Sheet) {
        job?.cancel()
        sheet = Sheet(title)
        job = viewModelScope.launch {
            sheet = try { block().copy(title = title, busy = false) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { Sheet(title, busy = false, error = e.message ?: e.toString()) }
        }
    }

    fun closeSheet() { job?.cancel(); sheet = null; askKind = -1 }

    suspend fun reflowText(i: Int): String = TextClean.clean(doc!!.pageText(i), repeated, 2, true)

    private suspend fun needText(i: Int): String {
        val t = reflowText(i)
        if (t.isBlank()) throw AiException("This page has no selectable text (it may be a scanned image or an empty page).")
        return t
    }

    private suspend fun translate(text: String): List<Pair<String, String>> {
        val lang = prefs.lang.value
        val key = lang + "|" + text.hashCode()
        trCache[key]?.let { return it }
        val r = Prompts.parsePairs(Ai.ask(prefs, Prompts.translate(lang), text), text)
        trCache[key] = r
        return r
    }

    fun translatePage() { askKind = -1; val p = page; run("Translate · page ${p + 1}") { Sheet(pairs = translate(needText(p)), page = p) } }
    fun translateText(t: String) { askKind = -1; run("Translate") { Sheet(pairs = translate(t)) } }
    fun explainPage(level: Int = 1) { askKind = -1; val p = page; run("Explain · page ${p + 1}") { Sheet(text = Ai.ask(prefs, Prompts.explain(prefs.lang.value, level), needText(p))) } }
    fun explainText(t: String, level: Int) {
        askKind = -1
        val name = when (level) { 0 -> "Explain simply"; 2 -> "Explain technically"; else -> "Explain" }
        run(name) { Sheet(text = Ai.ask(prefs, Prompts.explain(prefs.lang.value, level), t)) }
    }
    fun summarizePage() { askKind = -1; val p = page; run("Summary · page ${p + 1}") { Sheet(text = Ai.ask(prefs, Prompts.summarize(prefs.lang.value), needText(p))) } }
    fun summarizeText(t: String) { askKind = -1; run("Summary") { Sheet(text = Ai.ask(prefs, Prompts.summarize(prefs.lang.value), t)) } }
    fun keyPoints() { askKind = -1; val p = page; run("Key points · page ${p + 1}") { Sheet(text = Ai.ask(prefs, Prompts.keyPoints(prefs.lang.value), needText(p))) } }
    fun studyPage() { askKind = -1; val p = page; run("Study · page ${p + 1}") { Sheet(text = Ai.ask(prefs, Prompts.study(prefs.lang.value), needText(p))) } }

    fun analyzePage() {
        askKind = -1
        val p = page
        run("Analyze · page ${p + 1}") {
            val raw = Ai.ask(prefs, Prompts.analyze, needText(p))
            val found = Prompts.parseFound(raw)
            if (found.isEmpty()) throw AiException("The AI didn't return any passages. Try again.")
            Sheet(found = found, page = p)
        }
    }

    fun applyFound(s: Sheet) {
        val a = ann ?: return
        s.found?.forEach { (type, text) -> a.addHl(Hl(s.page, text, HlColors.byType[type] ?: HlColors.yellow)) }
        closeSheet()
    }

    fun openAsk(kind: Int, context: String, title: String) {
        job?.cancel(); askKind = kind; askText = context
        sheet = Sheet(title, busy = false)
    }

    fun askPage() { val p = page; viewModelScope.launch { try { openAsk(0, needText(p), "Ask · page ${p + 1}") } catch (e: Exception) { sheet = Sheet("Ask", false, e.message) } } }

    fun followUp(q: String) {
        val cur = sheet ?: return
        if (q.isBlank()) return
        job?.cancel()
        sheet = cur.copy(busy = true, error = null)
        job = viewModelScope.launch {
            try {
                val ans = if (askKind == 2) bookAnswer(q)
                else Ai.ask(prefs, Prompts.askCtx(prefs.lang.value), "Context:\n$askText\n\nQuestion: $q")
                sheet = cur.copy(busy = false, text = (cur.text + "\n\n**❓ $q**\n" + ans).trim())
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { sheet = cur.copy(busy = false, error = e.message ?: e.toString()) }
        }
    }

    private suspend fun bookAnswer(q: String): String {
        val d = doc ?: throw AiException("No book is open.")
        if (!indexDone) throw AiException("Still indexing the book (${indexProgress}/${d.pageCount} pages). Try again in a moment.")
        val kw = try {
            Ai.ask(prefs, "Extract search keywords.", Prompts.keywords(q))
                .split(',', '\n').map { it.trim().lowercase() }.filter { it.length > 2 }.take(14)
        } catch (e: AiException) { throw e } catch (e: Exception) {
            q.lowercase().split(Regex("\\W+")).filter { it.length > 2 }
        }
        val hits = d.retrieve(kw, 6)
        if (hits.isEmpty()) return "I couldn't find anything relevant in this book."
        val ctxt = hits.joinToString("\n\n") { "[Page ${it.first + 1}]\n${it.second}" }
        val ans = Ai.ask(prefs, Prompts.askBook(prefs.lang.value), "Excerpts:\n$ctxt\n\nQuestion: $q")
        return ans + "\n\n_Pages searched: " + hits.map { it.first + 1 }.sorted().joinToString(", ") + "_"
    }

    fun findInBook(term: String) {
        askKind = -1
        val d = doc ?: return
        val hits = d.search(term, 60)
        sheet = Sheet("“${term.take(40)}” in this book", busy = false, hits = hits,
            error = if (hits.isEmpty()) (if (indexDone) "No matches." else "Book is still being indexed — try again soon.") else null)
    }

    fun buildBookIndex() {
        askKind = -1
        val d = doc ?: return
        run("AI Book Index") {
            if (!indexDone) throw AiException("Still indexing the book (${indexProgress}/${d.pageCount}). Try again in a moment.")
            val cand = (d.outline().ifEmpty { d.headings() }).take(450)
            if (cand.isEmpty()) throw AiException("No headings were detected in this book.")
            val raw = Ai.ask(prefs, Prompts.tocBuilder, cand.joinToString("\n") { "${it.page + 1}|${it.title}" })
            val items = raw.lines().mapNotNull { l ->
                val parts = l.trim().split('|')
                if (parts.size < 3) null else {
                    val lv = parts[0].trim().toIntOrNull(); val pg = parts.last().trim().toIntOrNull()
                    if (lv == null || pg == null) null else TocItem(parts.subList(1, parts.size - 1).joinToString("|").trim(), (pg - 1).coerceIn(0, d.pageCount - 1), lv.coerceIn(0, 3))
                }
            }
            if (items.isEmpty()) throw AiException("Couldn't read the AI's answer. Try again.")
            toc.clear(); toc.addAll(items)
            Sheet(text = "Built an index with ${items.size} entries. Open **Contents** from the ⋮ menu to browse it.")
        }
    }

    // ---------------------------------------------------------------- highlights
    fun highlight(t: String, color: Int = HlColors.yellow, note: String = "") { ann?.addHl(Hl(page, t, color, note)) }

    // ---------------------------------------------------------------- speech
    private fun speaker(): Speaker = speaker ?: Speaker(ctx).also { s ->
        s.onWarn = { m -> Toast.makeText(ctx, m, Toast.LENGTH_LONG).show() }
        speaker = s
    }

    fun stopSpeaking() { speaker?.stop(); speaking = false; nowSpeaking = "" }

    private fun begin(items: List<Speaker.Item>, thenNext: Boolean) {
        if (items.isEmpty()) { speaking = false; Toast.makeText(ctx, "Nothing readable here.", Toast.LENGTH_SHORT).show(); return }
        speaking = true
        speaker().start(items, { prefs.ttsRate.value }, { _, it -> nowSpeaking = it.text }) {
            viewModelScope.launch {
                speaking = false; nowSpeaking = ""
                val d = doc
                if (thenNext && prefs.continuous.value && d != null && page < d.pageCount - 1) { goto(page + 1); readPage() }
            }
        }
    }

    private fun locFor(t: String): Locale =
        if (t.any { it in '\u0600'..'\u06FF' }) Locale.forLanguageTag(Langs.tag(prefs.lang.value).takeIf { it != "en-US" } ?: "fa-IR") else Locale.US

    fun readPage() {
        val d = doc ?: return
        val p = page
        stopSpeaking(); speaking = true; nowSpeaking = "Preparing…"
        viewModelScope.launch {
            try {
                val raw = d.pageText(p)
                var t = TextClean.clean(raw, repeated, prefs.tableMode.value, prefs.readCaptions.value)
                if (prefs.aiClean.value && raw.isNotBlank()) t = try { Ai.ask(prefs, Prompts.cleanForTts(prefs.tableMode.value), raw) } catch (e: Exception) { t }
                if (t.isBlank()) throw AiException("No readable text on this page.")
                val en = Locale.US
                val tr = Locale.forLanguageTag(Langs.tag(prefs.lang.value))
                val items = when (prefs.readMode.value) {
                    0 -> Speaker.sentences(t).map { Speaker.Item(it, en) }
                    else -> {
                        val pairs = translate(t)
                        pairs.flatMap { pr ->
                            val tl = Speaker.sentences(pr.second).map { Speaker.Item(it, tr) }
                            if (prefs.readMode.value == 1) tl else Speaker.sentences(pr.first).map { Speaker.Item(it, en) } + tl
                        }
                    }
                }
                begin(items, true)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { speaking = false; nowSpeaking = ""; Toast.makeText(ctx, e.message ?: "Error", Toast.LENGTH_LONG).show() }
        }
    }

    fun readText(t: String) { stopSpeaking(); begin(Speaker.sentences(t).map { Speaker.Item(it, locFor(it)) }, false) }

    fun speakSheet(s: Sheet) {
        stopSpeaking()
        val items = if (s.pairs != null) s.pairs.flatMap { pr -> Speaker.sentences(pr.second).map { Speaker.Item(it, locFor(it)) } }
        else Speaker.sentences(s.text.replace("**", "")).map { Speaker.Item(it, locFor(it)) }
        begin(items, false)
    }

    override fun onCleared() { speaker?.shutdown(); doc?.close() }
}
