package app.aireader

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent {
            val vm: AppVm = viewModel()
            AppTheme(vm.prefs.theme.value) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App(vm) }
            }
        }
        if (savedInstanceState == null) handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val uri = i?.data ?: return
        if (i.action == Intent.ACTION_VIEW) androidx.lifecycle.ViewModelProvider(this)[AppVm::class.java].open(uri)
    }
}

@Composable
fun App(vm: AppVm) {
    BackHandler(enabled = vm.screen != 0) {
        if (vm.screen == 2) vm.screen = if (vm.doc != null && vm.backTo == 1) 1 else 0
        else { vm.stopSpeaking(); vm.screen = 0 }
    }
    when (vm.screen) {
        0 -> HomeScreen(vm)
        1 -> ReaderScreen(vm)
        else -> SettingsScreen(vm)
    }
}
