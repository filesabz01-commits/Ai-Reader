package app.aireader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.LruCache
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.ln

data class TocItem(val title: String, val page: Int, val level: Int)

class PdfDoc(private val ctx: Context, val uri: Uri) {
    val id: String = Integer.toHexString(uri.toString().hashCode())
    private val file = File(ctx.cacheDir, "doc_$id.pdf")
    private val idxFile = File(ctx.cacheDir, "idx_$id.json")
    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var pd: PDDocument? = null
    private val renderLock = Mutex()
    private val textLock = Any()
    private val texts = ConcurrentHashMap<Int, String>()
    private val cache = object : LruCache<String, Bitmap>(56 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    var pageCount = 0
        private set
    var title = "PDF"
        private set

    suspend fun open() = withContext(Dispatchers.IO) {
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) title = c.getString(i).removeSuffix(".pdf").removeSuffix(".PDF")
            }
        } catch (_: Exception) {}
        if (!file.exists() || file.length() == 0L) {
            ctx.contentResolver.openInputStream(uri)!!.use { input -> file.outputStream().use { input.copyTo(it) } }
        }
        val f = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        pfd = f
        renderer = PdfRenderer(f).also { pageCount = it.pageCount }
    }

    fun close() {
        try { renderer?.close() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        try { pd?.close() } catch (_: Exception) {}
        cache.evictAll()
    }

    suspend fun render(i: Int, widthPx: Int): Bitmap {
        val key = "$i@$widthPx"
        cache.get(key)?.let { return it }
        return renderLock.withLock {
            cache.get(key) ?: withContext(Dispatchers.Default) {
                renderer!!.openPage(i).use { page ->
                    val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    cache.put(key, bmp)
                    bmp
                }
            }
        }
    }

    private fun pdDoc(): PDDocument = pd ?: PDDocument.load(file, MemoryUsageSetting.setupTempFileOnly()).also { pd = it }

    suspend fun pageText(i: Int): String = withContext(Dispatchers.IO) {
        texts[i] ?: synchronized(textLock) {
            texts[i] ?: run {
                val s = PDFTextStripper()
                s.sortByPosition = true
                s.startPage = i + 1
                s.endPage = i + 1
                val t = try { s.getText(pdDoc()) } catch (e: Exception) { "" }
                texts[i] = t
                t
            }
        }
    }

    /** Extracts every page once (cached on disk) so search / "ask the book" work. */
    suspend fun indexAll(onProgress: (Int) -> Unit) = withContext(Dispatchers.IO) {
        if (idxFile.exists()) {
            try {
                val arr = JSONArray(idxFile.readText())
                if (arr.length() == pageCount) {
                    for (i in 0 until pageCount) texts[i] = arr.getString(i)
                    onProgress(pageCount)
                    return@withContext
                }
            } catch (_: Exception) {}
        }
        for (i in 0 until pageCount) {
            pageText(i)
            if (i % 5 == 0) onProgress(i)
        }
        try {
            val arr = JSONArray()
            for (i in 0 until pageCount) arr.put(texts[i] ?: "")
            idxFile.writeText(arr.toString())
        } catch (_: Exception) {}
        onProgress(pageCount)
    }

    fun cachedText(i: Int): String = texts[i] ?: ""

    fun search(q: String, max: Int = 80): List<Pair<Int, String>> {
        val needle = q.trim().lowercase()
        if (needle.length < 2) return emptyList()
        val out = mutableListOf<Pair<Int, String>>()
        for (i in 0 until pageCount) {
            val t = texts[i] ?: continue
            val flat = t.replace(Regex("\\s+"), " ")
            val at = flat.lowercase().indexOf(needle)
            if (at >= 0) {
                val s = (at - 50).coerceAtLeast(0)
                val e = (at + needle.length + 70).coerceAtMost(flat.length)
                out.add(i to "…" + flat.substring(s, e) + "…")
                if (out.size >= max) break
            }
        }
        return out
    }

    /** Simple keyword retrieval (TF x IDF) used by "Ask this book". */
    fun retrieve(keywords: List<String>, k: Int = 6): List<Pair<Int, String>> {
        if (keywords.isEmpty()) return emptyList()
        val lower = (0 until pageCount).map { (texts[it] ?: "").lowercase() }
        val n = pageCount.toDouble()
        val scores = DoubleArray(pageCount)
        for (kw in keywords.distinct()) {
            val df = lower.count { it.contains(kw) }
            if (df == 0) continue
            val idf = ln(1 + n / (1 + df))
            for (i in 0 until pageCount) {
                var c = 0; var from = 0
                while (c < 10) {
                    val at = lower[i].indexOf(kw, from)
                    if (at < 0) break
                    c++; from = at + kw.length
                }
                scores[i] += c * idf
            }
        }
        return scores.withIndex().filter { it.value > 0 }.sortedByDescending { it.value }.take(k)
            .map { it.index to (texts[it.index] ?: "").replace(Regex("\\s+"), " ").take(2400) }
    }

    suspend fun outline(): List<TocItem> = withContext(Dispatchers.IO) {
        try {
            val d = synchronized(textLock) { pdDoc() }
            val ol = d.documentCatalog.documentOutline ?: return@withContext emptyList()
            val res = mutableListOf<TocItem>()
            walk(d, ol.firstChild, 0, res)
            res
        } catch (e: Exception) { emptyList() }
    }

    private fun walk(d: PDDocument, first: PDOutlineItem?, lvl: Int, out: MutableList<TocItem>) {
        var cur = first
        while (cur != null) {
            val pg = try { cur.findDestinationPage(d)?.let { d.pages.indexOf(it) } } catch (e: Exception) { null }
            if (pg != null && pg >= 0) out.add(TocItem(cur.title ?: "", pg, lvl))
            walk(d, cur.firstChild, lvl + 1, out)
            cur = cur.nextSibling
        }
    }

    /** Fallback table of contents guessed from heading-looking lines. */
    fun headings(): List<TocItem> {
        val chapter = Regex("^(chapter|part|appendix)\\s+[0-9A-Z]+.{0,70}$", RegexOption.IGNORE_CASE)
        val numbered = Regex("^(\\d{1,2})((\\.\\d{1,2}){0,2})\\s+[A-Z][A-Za-z ,&\\-/()]{3,70}$")
        val out = mutableListOf<TocItem>()
        for (i in 0 until pageCount) {
            val lines = (texts[i] ?: "").lines().map { it.trim() }.filter { it.isNotEmpty() }
            for (l in lines.take(40)) {
                if (chapter.matches(l)) out.add(TocItem(l, i, 0))
                else {
                    val m = numbered.matchEntire(l)
                    if (m != null && !l.endsWith(".") ) out.add(TocItem(l, i, m.groupValues[2].count { it == '.' }.coerceAtMost(2)))
                }
            }
        }
        return out.distinctBy { it.title }
    }
}

object TextClean {
    private val pageNo = Regex("^(page\\s*)?[-–—]?\\s*\\d{1,4}\\s*[-–—]?(\\s*(of|/)\\s*\\d{1,4})?$", RegexOption.IGNORE_CASE)
    private val caption = Regex("^(figure|fig\\.?|table|illustration|photo)\\s*\\d+[\\w.\\-]*\\s*[:.\\-–—]?\\s", RegexOption.IGNORE_CASE)

    private fun norm(l: String) = l.trim().replace(Regex("\\d+"), "#")

    /** Lines that repeat at the top/bottom of many pages = running headers/footers. */
    fun repeated(pages: List<String>): Set<String> {
        if (pages.size < 4) return emptySet()
        val cnt = HashMap<String, Int>()
        for (t in pages) {
            val ls = t.lines().map { it.trim() }.filter { it.isNotEmpty() }
            (ls.take(3) + ls.takeLast(3)).map(::norm).toSet().forEach { cnt[it] = (cnt[it] ?: 0) + 1 }
        }
        val need = maxOf(3, (pages.size * 0.4).toInt())
        return cnt.filter { it.value >= need && it.key.length > 1 }.keys
    }

    private fun tabular(l: String): Boolean {
        val toks = l.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (toks.size < 2) return false
        val digits = toks.count { t -> t.any { it.isDigit() } }
        return digits * 2 >= toks.size && !l.endsWith(".")
    }

    /** tableMode: 0 skip tables, 1 mention them briefly, 2 keep everything. */
    fun clean(raw: String, rep: Set<String>, tableMode: Int, captions: Boolean): String {
        val lines = raw.lines().map { it.trim() }.filterNot { l ->
            l.isNotEmpty() && (pageNo.matches(l) || norm(l) in rep)
        }
        val out = StringBuilder()
        val para = StringBuilder()
        fun flush() {
            if (para.isNotBlank()) { if (out.isNotEmpty()) out.append("\n\n"); out.append(para.toString().trim()) }
            para.clear()
        }
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.isEmpty()) { flush(); i++; continue }
            if (caption.containsMatchIn("$l ")) {
                if (captions) { flush(); para.append(l) } else flush()
                i++; continue
            }
            if (tabular(l)) {
                var j = i
                while (j < lines.size && lines[j].isNotEmpty() && tabular(lines[j])) j++
                if (j - i >= 3) {
                    flush()
                    when (tableMode) {
                        0 -> {}
                        1 -> para.append("A table is shown here.")
                        else -> para.append(lines.subList(i, j).joinToString(". "))
                    }
                    flush()
                    i = j; continue
                }
            }
            if (para.isNotEmpty()) {
                if (para.endsWith("-") && l.firstOrNull()?.isLowerCase() == true) para.setLength(para.length - 1)
                else para.append(' ')
            }
            para.append(l)
            i++
        }
        flush()
        return out.toString()
    }

    /** Whitespace-tolerant regex used to find a stored snippet again inside the displayed text. */
    fun regexFor(snippet: String): Regex {
        val toks = snippet.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        return Regex(toks.joinToString("\\s+") { Regex.escape(it) })
    }
}
