package app.aireader

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** A preference that is both persisted and observable by Compose. */
class Pref<T : Any>(private val sp: SharedPreferences, private val k: String, private val d: T) {
    private val st = mutableStateOf(load())
    var value: T
        get() = st.value
        set(x) { st.value = x; save(x) }

    @Suppress("UNCHECKED_CAST")
    private fun load(): T = when (d) {
        is Int -> sp.getInt(k, d) as T
        is Float -> sp.getFloat(k, d) as T
        is Boolean -> sp.getBoolean(k, d) as T
        else -> (sp.getString(k, d as String) ?: d) as T
    }

    private fun save(x: T) {
        val e = sp.edit()
        when (x) {
            is Int -> e.putInt(k, x)
            is Float -> e.putFloat(k, x)
            is Boolean -> e.putBoolean(k, x)
            else -> e.putString(k, x as String)
        }
        e.apply()
    }
}

class Prefs(ctx: Context) {
    val sp: SharedPreferences = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    // API keys live in Android's encrypted storage (never inside the APK).
    private val secure: SharedPreferences = try {
        EncryptedSharedPreferences.create(
            ctx, "secure_prefs",
            MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("secure_fallback", Context.MODE_PRIVATE)
    }

    val provider = Pref(sp, "provider", "gemini")
    val lang = Pref(sp, "lang", "Persian")
    val theme = Pref(sp, "theme", 0)            // 0 light, 1 dark, 2 sepia
    val viewMode = Pref(sp, "viewMode", 0)      // 0 page, 1 scroll, 2 reflow text
    val twoPage = Pref(sp, "twoPage", false)
    val fontSize = Pref(sp, "fontSize", 18f)
    val tableMode = Pref(sp, "tableMode", 1)    // 0 never, 1 brief, 2 everything
    val readCaptions = Pref(sp, "readCaptions", false)
    val readMode = Pref(sp, "readMode", 0)      // 0 original, 1 translation, 2 both
    val displayMode = Pref(sp, "displayMode", 2)
    val aiClean = Pref(sp, "aiClean", false)
    val ttsRate = Pref(sp, "ttsRate", 1.0f)
    val continuous = Pref(sp, "continuous", false)

    fun key(p: String): String = secure.getString("key_$p", "") ?: ""
    fun setKey(p: String, v: String) { secure.edit().putString("key_$p", v.trim()).apply() }
    fun model(p: String): String = sp.getString("model_$p", null) ?: Providers.byId(p).defModel
    fun setModel(p: String, v: String) { sp.edit().putString("model_$p", v.trim()).apply() }
    fun base(p: String): String = sp.getString("base_$p", null) ?: Providers.byId(p).defBase
    fun setBase(p: String, v: String) { sp.edit().putString("base_$p", v.trim()).apply() }
}
