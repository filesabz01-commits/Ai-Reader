@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package app.aireader

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.platform.TextToolbar
import androidx.compose.ui.platform.TextToolbarStatus
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

enum class Panel { NONE, SEARCH, TOC, MARKS, ASKBOOK, JUMP, NOTE }

private val darkMatrix = floatArrayOf(
    -1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f
)
private val sepiaMatrix = floatArrayOf(
    0.95f, 0f, 0f, 0f, 0f, 0f, 0.88f, 0f, 0f, 0f, 0f, 0f, 0.72f, 0f, 0f, 0f, 0f, 0f, 1f, 0f
)

fun grabSelection(ctx: Context, copy: () -> Unit): String {
    copy()
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    return cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()?.trim().orEmpty()
}

@Composable
fun ReaderScreen(vm: AppVm) {
    val doc = vm.doc ?: return
    val ann = vm.ann ?: return
    val p = vm.prefs
    val ctx = LocalContext.current
    val n = doc.pageCount
    var panel by remember { mutableStateOf(Panel.NONE) }
    var aiMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var selCopy by remember { mutableStateOf<(() -> Unit)?>(null) }
    var noteText by remember { mutableStateOf("") }
    val bookmarked = ann.bookmarks.contains(vm.page)

    fun withSel(f: (String) -> Unit) {
        val c = selCopy ?: return
        val t = grabSelection(ctx, c)
        selCopy = null
        if (t.isNotBlank()) f(t)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(doc.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp) },
                navigationIcon = { IconButton(onClick = { vm.stopSpeaking(); vm.screen = 0 }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                actions = {
                    Box {
                        TextButton(onClick = { aiMenu = true }) { Text("✨ AI") }
                        DropdownMenu(expanded = aiMenu, onDismissRequest = { aiMenu = false }) {
                            @Composable fun item(label: String, f: () -> Unit) = DropdownMenuItem(text = { Text(label) }, onClick = { aiMenu = false; f() })
                            item("🌐 Translate page") { vm.translatePage() }
                            item("🧠 Explain page") { vm.explainPage() }
                            item("📝 Summarize") { vm.summarizePage() }
                            item("🔑 Key points") { vm.keyPoints() }
                            item("❓ Ask about this page") { vm.askPage() }
                            item("🔊 Read this page") { vm.readPage() }
                            item("🖍 Analyze & highlight") { vm.analyzePage() }
                            item("🎯 Study this page") { vm.studyPage() }
                        }
                    }
                    IconButton(onClick = { panel = Panel.SEARCH }) { Icon(Icons.Default.Search, "Search") }
                    IconButton(onClick = { ann.toggleBookmark(vm.page) }) {
                        Icon(if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Bookmark")
                    }
                    Box {
                        IconButton(onClick = { moreMenu = true }) { Icon(Icons.Default.MoreVert, "More") }
                        DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                            @Composable fun item(label: String, f: () -> Unit) = DropdownMenuItem(text = { Text(label) }, onClick = { moreMenu = false; f() })
                            item("Contents") { panel = Panel.TOC }
                            item("Bookmarks, highlights & notes") { panel = Panel.MARKS }
                            item("🧠 Ask this book") { panel = Panel.ASKBOOK; }
                            item("📚 AI Book Index") { vm.buildBookIndex() }
                            item("Jump to page") { panel = Panel.JUMP }
                            item("View: Page") { p.viewMode.value = 0 }
                            item("View: Scroll") { p.viewMode.value = 1 }
                            item("View: Reflow text (select & AI)") { p.viewMode.value = 2 }
                            item(if (p.twoPage.value) "Two pages: ON" else "Two pages: OFF") { p.twoPage.value = !p.twoPage.value }
                            item("Theme: Light / Dark / Sepia") { p.theme.value = (p.theme.value + 1) % 3 }
                            item("Text size +") { p.fontSize.value = (p.fontSize.value + 2f).coerceAtMost(40f) }
                            item("Text size −") { p.fontSize.value = (p.fontSize.value - 2f).coerceAtLeast(12f) }
                            item("Settings") { vm.backTo = 1; vm.screen = 2 }
                        }
                    }
                }
            )
        },
        bottomBar = {
            Column(Modifier.background(MaterialTheme.colorScheme.surface)) {
                if (selCopy != null) {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        @Composable fun chip(label: String, f: (String) -> Unit) = AssistChip(onClick = { withSel(f) }, label = { Text(label) })
                        chip("Translate") { vm.translateText(it) }
                        chip("Explain") { vm.explainText(it, 1) }
                        chip("Simple") { vm.explainText(it, 0) }
                        chip("Technical") { vm.explainText(it, 2) }
                        chip("Summarize") { vm.summarizeText(it) }
                        chip("Ask AI") { vm.openAsk(1, it, "Ask · selection") }
                        chip("Speak") { vm.readText(it) }
                        chip("Highlight") { vm.highlight(it) }
                        chip("Note") { noteText = it; panel = Panel.NOTE }
                        chip("Find in book") { vm.findInBook(it) }
                        chip("Copy") { }
                    }
                }
                if (vm.speaking) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🔊 " + vm.nowSpeaking, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, modifier = Modifier.weight(1f),
                            style = TextStyle(textDirection = TextDirection.Content))
                        IconButton(onClick = { vm.stopSpeaking() }) { Icon(Icons.Default.Stop, "Stop") }
                    }
                }
                if (!vm.indexDone) {
                    LinearProgressIndicator(progress = { vm.indexProgress / n.toFloat() }, modifier = Modifier.fillMaxWidth())
                }
                var drag by remember { mutableStateOf<Float?>(null) }
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { vm.goto(vm.page - 1) }) { Icon(Icons.Default.ChevronLeft, "Previous") }
                    Slider(
                        value = drag ?: vm.page.toFloat(), onValueChange = { drag = it },
                        onValueChangeFinished = { drag?.let { vm.goto(it.roundToInt()) }; drag = null },
                        valueRange = 0f..(n - 1).coerceAtLeast(1).toFloat(), modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { vm.goto(vm.page + 1) }) { Icon(Icons.Default.ChevronRight, "Next") }
                }
                Text("${vm.page + 1} / $n  ·  ${((vm.page + 1) * 100f / n).roundToInt()}%", fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 6.dp))
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (p.viewMode.value) {
                0 -> PagerView(vm)
                1 -> ScrollView(vm)
                else -> ReflowView(vm) { selCopy = it }
            }
            if (p.viewMode.value != 2) {
                SmallFloatingActionButton(
                    onClick = { p.viewMode.value = 2 },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp)
                ) { Icon(Icons.Default.TextFields, "Select text") }
            }
        }
    }

    // ------------------------------------------------------------ panels
    if (panel == Panel.SEARCH) SearchPanel(vm) { panel = Panel.NONE }
    if (panel == Panel.TOC) TocPanel(vm) { panel = Panel.NONE }
    if (panel == Panel.MARKS) MarksPanel(vm) { panel = Panel.NONE }
    if (panel == Panel.JUMP) {
        var t by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { panel = Panel.NONE },
            title = { Text("Jump to page (1–$n)") },
            text = { OutlinedTextField(t, { t = it.filter(Char::isDigit) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { t.toIntOrNull()?.let { vm.goto(it - 1) }; panel = Panel.NONE }) { Text("Go") } },
            dismissButton = { TextButton(onClick = { panel = Panel.NONE }) { Text("Cancel") } }
        )
    }
    if (panel == Panel.NOTE) {
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { panel = Panel.NONE },
            title = { Text("Add note") },
            text = { Column { Text(noteText.take(120), fontSize = 13.sp); OutlinedTextField(note, { note = it }, placeholder = { Text("Your note") }) } },
            confirmButton = { TextButton(onClick = { vm.highlight(noteText, HlColors.orange, note.ifBlank { "•" }); panel = Panel.NONE }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { panel = Panel.NONE }) { Text("Cancel") } }
        )
    }
    if (panel == Panel.ASKBOOK) {
        var q by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { panel = Panel.NONE },
            title = { Text("Ask this book") },
            text = { OutlinedTextField(q, { q = it }, placeholder = { Text("e.g. What is cavitation?") }) },
            confirmButton = {
                TextButton(onClick = { if (q.isNotBlank()) { vm.openAsk(2, "", "Ask this book"); vm.followUp(q) }; panel = Panel.NONE }) { Text("Ask") }
            },
            dismissButton = { TextButton(onClick = { panel = Panel.NONE }) { Text("Cancel") } }
        )
    }
    vm.sheet?.let { AiSheet(vm, it) }
}

// ====================================================================== page views

@Composable
fun PageImage(vm: AppVm, idx: Int, widthPx: Int, modifier: Modifier = Modifier) {
    val bmp by produceState<Bitmap?>(null, idx, widthPx) { value = try { vm.doc?.render(idx, widthPx) } catch (e: Exception) { null } }
    val filter = when (vm.prefs.theme.value) {
        1 -> ColorFilter.colorMatrix(ColorMatrix(darkMatrix))
        2 -> ColorFilter.colorMatrix(ColorMatrix(sepiaMatrix))
        else -> null
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), null, modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth, colorFilter = filter)
    else Box(modifier.fillMaxWidth().aspectRatio(0.7f), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(28.dp)) }
}

@Composable
fun PagerView(vm: AppVm) {
    val doc = vm.doc ?: return
    val n = doc.pageCount
    val per = if (vm.prefs.twoPage.value) 2 else 1
    val count = (n + per - 1) / per
    val state = rememberPagerState(initialPage = (vm.page / per).coerceIn(0, count - 1)) { count }
    var zoom by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    val density = LocalDensity.current
    val widthPx = with(density) { (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.dp.toPx() * 1.5f / per).toInt() }

    LaunchedEffect(vm.page, per) { val t = vm.page / per; if (state.currentPage != t && t < count) state.scrollToPage(t) }
    LaunchedEffect(state.currentPage) {
        zoom = 1f; off = Offset.Zero
        if (state.currentPage != vm.page / per) vm.goto(state.currentPage * per)
    }
    Box(
        Modifier.fillMaxSize().onSizeChanged { size = it }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { if (zoom > 1f) { zoom = 1f; off = Offset.Zero } else zoom = 2.4f }) }
            .pointerInput(zoom > 1f) {
                if (zoom > 1f) detectTransformGestures { _, pan, z, _ ->
                    zoom = (zoom * z).coerceIn(1f, 5f)
                    val mx = size.width * (zoom - 1f) / 2f; val my = size.height * (zoom - 1f) / 2f
                    off = Offset((off.x + pan.x).coerceIn(-mx, mx), (off.y + pan.y).coerceIn(-my, my))
                }
            }
    ) {
        HorizontalPager(state, userScrollEnabled = zoom <= 1f, modifier = Modifier.fillMaxSize().graphicsLayer {
            scaleX = zoom; scaleY = zoom; translationX = off.x; translationY = off.y
        }) { pg ->
            Row(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalAlignment = Alignment.Top) {
                for (k in 0 until per) {
                    val idx = pg * per + k
                    if (idx < n) PageImage(vm, idx, widthPx, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun ScrollView(vm: AppVm) {
    val doc = vm.doc ?: return
    val ls = rememberLazyListState(initialFirstVisibleItemIndex = vm.page)
    val widthPx = with(LocalDensity.current) { (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.dp.toPx() * 1.3f).toInt() }
    LaunchedEffect(vm.page) { if (ls.firstVisibleItemIndex != vm.page) ls.scrollToItem(vm.page) }
    LaunchedEffect(ls) {
        snapshotFlow { ls.firstVisibleItemIndex }.collect { if (it != vm.page) vm.goto(it) }
    }
    LazyColumn(state = ls, modifier = Modifier.fillMaxSize()) {
        items(doc.pageCount) { i ->
            PageImage(vm, i, widthPx)
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
fun ReflowView(vm: AppVm, onSel: ((() -> Unit)?) -> Unit) {
    val ann = vm.ann ?: return
    val pg = vm.page
    val raw by produceState<String?>(null, pg, vm.repeated) { value = null; value = vm.reflowText(pg) }
    val text = raw
    val update by rememberUpdatedState(onSel)
    val toolbar = remember {
        object : TextToolbar {
            private var st = TextToolbarStatus.Hidden
            override val status: TextToolbarStatus get() = st
            override fun showMenu(rect: Rect, onCopyRequested: (() -> Unit)?, onPasteRequested: (() -> Unit)?,
                                  onCutRequested: (() -> Unit)?, onSelectAllRequested: (() -> Unit)?) {
                st = TextToolbarStatus.Shown; update(onCopyRequested)
            }
            override fun hide() { st = TextToolbarStatus.Hidden; update(null) }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState(), enabled = true).padding(16.dp)) {
        when {
            text == null -> CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
            text.isBlank() -> Text("No selectable text on this page (it may be an image or a blank page). Switch to Page view.")
            else -> {
                val hls = ann.highlights.filter { it.page == pg }
                val annotated = remember(text, hls.toList()) {
                    buildAnnotatedString {
                        append(text)
                        hls.forEach { h ->
                            TextClean.regexFor(h.text).find(text)?.let { m ->
                                addStyle(
                                    SpanStyle(background = Color(h.color).copy(alpha = 0.6f), color = Color.Black,
                                        textDecoration = if (h.note.isNotBlank()) TextDecoration.Underline else null),
                                    m.range.first, m.range.last + 1
                                )
                            }
                        }
                    }
                }
                CompositionLocalProvider(LocalTextToolbar provides toolbar) {
                    SelectionContainer {
                        Text(annotated, fontSize = vm.prefs.fontSize.value.sp, lineHeight = (vm.prefs.fontSize.value * 1.55f).sp)
                    }
                }
                Spacer(Modifier.height(48.dp))
            }
        }
    }
}

// ====================================================================== panels

@Composable
fun SearchPanel(vm: AppVm, onClose: () -> Unit) {
    val doc = vm.doc ?: return
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Pair<Int, String>>>(emptyList()) }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 16.dp).imePadding()) {
            OutlinedTextField(
                q, { q = it; if (vm.indexDone) results = doc.search(it) }, Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("Search in book") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { results = doc.search(q) })
            )
            if (!vm.indexDone) Text("Indexing book… ${vm.indexProgress}/${doc.pageCount} (search works when done)", fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(results) { (pg, snip) ->
                    Column(Modifier.fillMaxWidth().clickable { vm.goto(pg); onClose() }.padding(vertical = 8.dp)) {
                        Text("Page ${pg + 1}", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 13.sp)
                        Text(snip, fontSize = 14.sp)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun TocPanel(vm: AppVm, onClose: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onClose, containerColor = MaterialTheme.colorScheme.surface) {
        if (vm.toc.isEmpty()) Text(
            if (vm.indexDone) "No contents found in this PDF. Try ⋮ → AI Book Index." else "Still scanning the book…",
            modifier = Modifier.padding(16.dp)
        )
        LazyColumn(Modifier.heightIn(max = 520.dp).padding(bottom = 16.dp)) {
            items(vm.toc.toList()) { t ->
                Row(Modifier.fillMaxWidth().clickable { vm.goto(t.page); onClose() }.padding(start = (16 + t.level * 16).dp, end = 16.dp, top = 8.dp, bottom = 8.dp)) {
                    Text(t.title, Modifier.weight(1f), fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("${t.page + 1}", fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun MarksPanel(vm: AppVm, onClose: () -> Unit) {
    val ann = vm.ann ?: return
    ModalBottomSheet(onDismissRequest = onClose, containerColor = MaterialTheme.colorScheme.surface) {
        LazyColumn(Modifier.heightIn(max = 560.dp).padding(bottom = 16.dp)) {
            item { Text("Bookmarks", Modifier.padding(16.dp, 4.dp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
            if (ann.bookmarks.isEmpty()) item { Text("None yet — tap the bookmark icon.", Modifier.padding(16.dp, 4.dp), fontSize = 13.sp) }
            items(ann.bookmarks.toList()) { pg ->
                Row(Modifier.fillMaxWidth().clickable { vm.goto(pg); onClose() }.padding(16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Page ${pg + 1}", Modifier.weight(1f))
                    IconButton(onClick = { ann.toggleBookmark(pg) }) { Icon(Icons.Default.Delete, "Delete") }
                }
            }
            item { Text("Highlights & notes", Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
            if (ann.highlights.isEmpty()) item { Text("None yet — select text in Reflow view.", Modifier.padding(16.dp, 4.dp), fontSize = 13.sp) }
            items(ann.highlights.toList()) { h ->
                Row(Modifier.fillMaxWidth().clickable { vm.goto(h.page); onClose() }.padding(16.dp, 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(Color(h.color), androidx.compose.foundation.shape.CircleShape))
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text("Page ${h.page + 1}", fontSize = 11.sp)
                        Text(h.text, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        if (h.note.isNotBlank()) Text("📝 ${h.note}", fontSize = 13.sp)
                    }
                    IconButton(onClick = { ann.removeHl(h) }) { Icon(Icons.Default.Delete, "Delete") }
                }
            }
        }
    }
}
