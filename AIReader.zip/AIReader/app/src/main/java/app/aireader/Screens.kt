@file:OptIn(ExperimentalMaterial3Api::class)

package app.aireader

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(vm: AppVm) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { vm.open(it) } }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Reader") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                actions = { IconButton(onClick = { vm.backTo = 0; vm.screen = 2 }) { Icon(Icons.Default.Settings, "Settings") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
            Button(onClick = { picker.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth(), enabled = !vm.opening) {
                Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Open a PDF")
            }
            if (vm.opening) { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
            vm.openError?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
            if (vm.prefs.key(vm.prefs.provider.value).isBlank()) {
                Card(Modifier.fillMaxWidth().padding(top = 12.dp).clickable { vm.backTo = 0; vm.screen = 2 }) {
                    Text("Set up an AI provider and API key in Settings to use Translate / Explain / Ask.", Modifier.padding(12.dp), fontSize = 14.sp)
                }
            }
            if (vm.recents.isNotEmpty()) {
                Text("Recent", Modifier.padding(top = 20.dp, bottom = 4.dp), fontWeight = FontWeight.Bold)
                LazyColumn {
                    items(vm.recents.toList()) { r ->
                        Column(Modifier.fillMaxWidth().clickable { vm.open(android.net.Uri.parse(r.uri)) }.padding(vertical = 10.dp)) {
                            Text(r.title, fontSize = 16.sp)
                            Text("Page ${vm.lastPageOf(r.uri) + 1}", fontSize = 12.sp)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVm) {
    val p = vm.prefs
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                navigationIcon = { IconButton(onClick = { vm.screen = if (vm.doc != null && vm.backTo == 1) 1 else 0 }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("AI Providers", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Pick the provider the app uses. Keys are stored encrypted on this phone only.", fontSize = 12.sp)
            Providers.all.forEach { ProviderCard(p, it) }

            Text("Target language", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            var langMenu by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { langMenu = true }) { Text(p.lang.value) }
                DropdownMenu(langMenu, { langMenu = false }) {
                    Langs.all.forEach { (name, _) -> DropdownMenuItem(text = { Text(name) }, onClick = { p.lang.value = name; langMenu = false }) }
                }
            }

            Text("Reading aloud", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("What to read", fontSize = 13.sp)
            Choice(listOf("Original", "Translation", "Original + Translation"), p.readMode.value) { p.readMode.value = it }
            Text("Tables", fontSize = 13.sp)
            Choice(listOf("Never read", "Briefly", "Read everything"), p.tableMode.value) { p.tableMode.value = it }
            SwitchRow("Read figure/table captions", p.readCaptions.value) { p.readCaptions.value = it }
            SwitchRow("Clean page text with AI before reading (better, uses API)", p.aiClean.value) { p.aiClean.value = it }
            SwitchRow("Continue to next page automatically", p.continuous.value) { p.continuous.value = it }
            Text("Speed: ${"%.1f".format(p.ttsRate.value)}x", fontSize = 13.sp)
            Slider(p.ttsRate.value, { p.ttsRate.value = it }, valueRange = 0.5f..2f)

            Text("Display", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Choice(listOf("Light", "Dark", "Sepia"), p.theme.value) { p.theme.value = it }
            Choice(listOf("Page", "Scroll", "Reflow text"), p.viewMode.value) { p.viewMode.value = it }
            SwitchRow("Two pages side by side (Page view)", p.twoPage.value) { p.twoPage.value = it }
            Text("Reflow text size: ${p.fontSize.value.toInt()}", fontSize = 13.sp)
            Slider(p.fontSize.value, { p.fontSize.value = it }, valueRange = 12f..40f)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun SwitchRow(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        Switch(v, onChange)
    }
}

@Composable
fun ProviderCard(p: Prefs, info: ProviderInfo) {
    val active = p.provider.value == info.id
    val scope = rememberCoroutineScope()
    var key by remember(info.id) { mutableStateOf(p.key(info.id)) }
    var model by remember(info.id) { mutableStateOf(p.model(info.id)) }
    var base by remember(info.id) { mutableStateOf(p.base(info.id)) }
    var show by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var list by remember { mutableStateOf<List<String>>(emptyList()) }
    var menu by remember { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.clickable { p.provider.value = info.id }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(active, { p.provider.value = info.id })
                Text(info.label, fontWeight = FontWeight.Bold)
            }
            if (active) {
                if (info.id == "custom" || info.id == "openrouter") {
                    OutlinedTextField(base, { base = it; p.setBase(info.id, it) }, label = { Text("Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(
                    key, { key = it; p.setKey(info.id, it) }, label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { IconButton(onClick = { show = !show }) { Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Show") } }
                )
                OutlinedTextField(model, { model = it; p.setModel(info.id, it) }, label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box {
                        OutlinedButton(onClick = {
                            scope.launch {
                                status = "Loading models…"
                                try { list = Ai.models(p, info.id); status = "${list.size} models"; menu = list.isNotEmpty() }
                                catch (e: Exception) { status = e.message ?: "Error" }
                            }
                        }) { Text("Load models") }
                        DropdownMenu(menu, { menu = false }, Modifier.heightIn(max = 360.dp)) {
                            list.forEach { m -> DropdownMenuItem(text = { Text(m, fontSize = 13.sp) }, onClick = { model = m; p.setModel(info.id, m); menu = false }) }
                        }
                    }
                    Button(onClick = {
                        scope.launch {
                            status = "Testing…"
                            status = try { "✅ " + Ai.ask(p, "Reply with the single word OK.", "ping").take(60) } catch (e: Exception) { "❌ " + (e.message ?: "Error") }
                        }
                    }) { Text("Test") }
                }
                if (status.isNotBlank()) Text(status, fontSize = 12.sp)
            }
        }
    }
}
