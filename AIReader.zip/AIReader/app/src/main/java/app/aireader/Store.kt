package app.aireader

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

data class Hl(val page: Int, val text: String, val color: Int, val note: String = "")
data class Recent(val uri: String, val title: String)

object HlColors {
    val yellow = 0xFFFFF176.toInt()
    val orange = 0xFFFFCC80.toInt()
    val byType = mapOf(
        "definition" to 0xFFFFF176.toInt(), "formula" to 0xFF81D4FA.toInt(), "important" to 0xFFA5D6A7.toInt(),
        "warning" to 0xFFEF9A9A.toInt(), "term" to 0xFFCE93D8.toInt(), "example" to 0xFFFFCC80.toInt()
    )
}

class Annotations(ctx: Context, docId: String) {
    private val sp = ctx.getSharedPreferences("ann_$docId", Context.MODE_PRIVATE)
    val highlights = mutableStateListOf<Hl>()
    val bookmarks = mutableStateListOf<Int>()

    init {
        try {
            val h = JSONArray(sp.getString("hl", "[]"))
            for (i in 0 until h.length()) {
                val o = h.getJSONObject(i)
                highlights.add(Hl(o.getInt("p"), o.getString("t"), o.getInt("c"), o.optString("n")))
            }
            val b = JSONArray(sp.getString("bm", "[]"))
            for (i in 0 until b.length()) bookmarks.add(b.getInt(i))
        } catch (_: Exception) {}
    }

    private fun save() {
        val h = JSONArray()
        highlights.forEach { h.put(JSONObject().put("p", it.page).put("t", it.text).put("c", it.color).put("n", it.note)) }
        val b = JSONArray(); bookmarks.forEach { b.put(it) }
        sp.edit().putString("hl", h.toString()).putString("bm", b.toString()).apply()
    }

    fun addHl(h: Hl) { highlights.add(h); save() }
    fun removeHl(h: Hl) { highlights.remove(h); save() }
    fun toggleBookmark(p: Int) { if (!bookmarks.remove(p)) bookmarks.add(p); bookmarks.sort(); save() }
}
