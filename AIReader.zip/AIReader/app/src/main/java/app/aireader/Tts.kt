package app.aireader

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Sequential text-to-speech that can switch language per item (English original + Persian translation). */
class Speaker(ctx: Context) : UtteranceProgressListener() {
    data class Item(val text: String, val locale: Locale)

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: (() -> Unit)? = null
    private var items: List<Item> = emptyList()
    private var idx = 0
    private var rate: () -> Float = { 1f }
    private var onItem: (Int, Item) -> Unit = { _, _ -> }
    private var onFinish: () -> Unit = {}
    var onWarn: (String) -> Unit = {}
    @Volatile var playing = false
        private set

    init {
        tts = TextToSpeech(ctx.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(this)
            if (ready) pending?.invoke() else main.post { onWarn("Text-to-speech engine is not available on this phone.") }
            pending = null
        }
    }

    fun start(list: List<Item>, rate: () -> Float, onItem: (Int, Item) -> Unit, onFinish: () -> Unit) {
        stop()
        val go = {
            this.items = list; this.idx = 0; this.rate = rate; this.onItem = onItem; this.onFinish = onFinish
            playing = true
            next()
        }
        if (ready) go() else pending = go
    }

    private fun next() {
        if (!playing) return
        if (idx >= items.size) { playing = false; main.post { onFinish() }; return }
        val it = items[idx]
        val t = tts ?: return
        val r = t.setLanguage(it.locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            main.post { onWarn("No ${it.locale.displayLanguage} voice installed. Install it in Android Settings → Text-to-speech.") }
        }
        t.setSpeechRate(rate())
        val i = idx
        main.post { onItem(i, it) }
        t.speak(it.text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "u$i")
    }

    override fun onStart(utteranceId: String?) {}
    override fun onDone(utteranceId: String?) { idx++; next() }
    @Deprecated("Deprecated in Java")
    override fun onError(utteranceId: String?) { idx++; next() }

    fun stop() { playing = false; tts?.stop() }
    fun shutdown() { playing = false; tts?.stop(); tts?.shutdown() }

    companion object {
        fun sentences(t: String): List<String> =
            t.split(Regex("(?<=[.!?؟…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotBlank() }
    }
}
