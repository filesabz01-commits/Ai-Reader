@file:OptIn(ExperimentalMaterial3Api::class)

package app.aireader

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AppTheme(theme: Int, content: @Composable () -> Unit) {
    val cs = when (theme) {
        1 -> darkColorScheme(
            primary = Color(0xFF8AB4F8), background = Color(0xFF121212), surface = Color(0xFF1B1B1B),
            onBackground = Color(0xFFE6E1E5), onSurface = Color(0xFFE6E1E5)
        )
        2 -> lightColorScheme(
            primary = Color(0xFF8B5E34), background = Color(0xFFF4ECD8), surface = Color(0xFFEFE5CC),
            onBackground = Color(0xFF5B4636), onSurface = Color(0xFF5B4636), onPrimary = Color.White
        )
        else -> lightColorScheme(primary = Color(0xFF1A5FB4), background = Color.White, surface = Color(0xFFFAFAFA))
    }
    MaterialTheme(colorScheme = cs, content = content)
}

/** Tiny Markdown subset: **bold**, # headings, - bullets, _italic lines_. */
fun md(src: String): AnnotatedString = buildAnnotatedString {
    val bold = Regex("\\*\\*(.+?)\\*\\*")
    src.lines().forEachIndexed { i, l0 ->
        if (i > 0) append("\n")
        var l = l0
        var head = false
        if (l.startsWith("#")) { l = l.trimStart('#').trim(); head = true }
        if (l.startsWith("- ") || l.startsWith("* ")) l = "• " + l.drop(2)
        val start = length
        var pos = 0
        for (m in bold.findAll(l)) {
            append(l.substring(pos, m.range.first))
            pushStyle(SpanStyle(fontWeight = FontWeight.Bold)); append(m.groupValues[1]); pop()
            pos = m.range.last + 1
        }
        append(l.substring(pos))
        if (head) addStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 18.sp), start, length)
    }
}

@Composable
fun Choice(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o -> FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(o) }) }
    }
}

@Composable
fun AiSheet(vm: AppVm, s: Sheet) {
    val clip = LocalClipboardManager.current
    var q by remember(s.title) { mutableStateOf("") }
    val plain = s.pairs?.joinToString("\n\n") { it.first + "\n" + it.second } ?: s.text
    ModalBottomSheet(
        onDismissRequest = { vm.closeSheet() },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 12.dp).imePadding()) {
            Text(s.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                if (s.pairs != null) {
                    Choice(listOf("Original", "Translation", "Both"), vm.prefs.displayMode.value) { vm.prefs.displayMode.value = it }
                    Spacer(Modifier.height(8.dp))
                    s.pairs.forEach { (o, t) ->
                        if (vm.prefs.displayMode.value != 1) Text(o, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), style = TextStyle(textDirection = TextDirection.Content, fontSize = 14.sp))
                        if (vm.prefs.displayMode.value != 0) Text(t, style = TextStyle(textDirection = TextDirection.Content, fontSize = 17.sp, fontWeight = FontWeight.Medium))
                        Spacer(Modifier.height(10.dp))
                    }
                }
                if (s.found != null) {
                    Text("${s.found.size} important passages found:", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    s.found.forEach { (type, text) ->
                        Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                            Box(Modifier.padding(top = 5.dp).size(12.dp).clip(CircleShape).background(Color(HlColors.byType[type] ?: HlColors.yellow)))
                            Spacer(Modifier.width(8.dp))
                            Column { Text(type, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(text, fontSize = 14.sp) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { vm.applyFound(s) }) { Text("Apply highlights") }
                }
                if (s.hits != null) {
                    s.hits.forEach { (pg, snip) ->
                        Column(Modifier.fillMaxWidth().clickable { vm.goto(pg); vm.closeSheet() }.padding(vertical = 8.dp)) {
                            Text("Page ${pg + 1}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(snip, fontSize = 14.sp)
                        }
                        HorizontalDivider()
                    }
                }
                if (s.text.isNotBlank()) Text(md(s.text), style = TextStyle(textDirection = TextDirection.Content, fontSize = 16.sp, lineHeight = 24.sp))
                if (s.busy) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)); Text("Thinking…")
                }
                if (s.error != null) Text(s.error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp))
            }
            if (vm.askKind >= 0) {
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    placeholder = { Text(if (vm.askKind == 2) "Ask this book…" else "Ask a question…") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { vm.followUp(q); q = "" }),
                    trailingIcon = { IconButton(onClick = { vm.followUp(q); q = "" }) { Icon(Icons.Default.Send, "Send") } }
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.End) {
                if (plain.isNotBlank()) {
                    TextButton(onClick = { clip.setText(AnnotatedString(plain)) }) { Text("Copy") }
                    TextButton(onClick = { vm.speakSheet(s) }) { Text("🔊 Speak") }
                }
                TextButton(onClick = { vm.closeSheet() }) { Text("Close") }
            }
        }
    }
}
